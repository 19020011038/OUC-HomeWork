#include<iostream>
#include"config.h"
#include"tool.h"
#include"filedb.h"
#include<vector>
#include<string>
#include"rank.h"
#include"all_file_classes.h"



using namespace std;

FileDB db = FileDB("path");

//      int insert(string db_name,vector<T>&entity);
//      int Delete(string db_name,T& entity,vector<string>& value);
//      int update(string db_name,T& select_entity,T& new_entity,vector<string>& value);
//      int select(string db_name,T &entity,vector<string>&value,vector<T>&result);


bool Utils::CheckUserExist(User user) //参数：账户，返回是否存在该账户
{
    vector<string> value;
    value.push_back("not-all");
    value.push_back("account");
    vector<User> result;
    if (db.select("user", user, value, result) == -1)
        return false;
    return true;
}

bool Utils::CheckBookExist(Book book) //参数：isbn，返回是否存在该种书
{
    vector<string> value;
    value.push_back("not-all");
    value.push_back("isbn");
    vector<Book> result;
    if (db.select("user", book, value, result) == -1)
        return false;
    return true;
}

bool Utils::CheckIsbnBookIdExist(IsbnBookId ibi){
    vector<string> vec;
    vec.push_back("not-all");
    vec.push_back("isbn");
    vec.push_back("book_id");
    vector<IsbnBookId> res;
    if (db.select("isbn-book_id", ibi, vec, res) != -1)
        return true;
    else
        return false;
}

bool Utils::CheckStudentBookExist(StudentBook sb){
    vector<string> vec;
    vec.push_back("not-all");
    vec.push_back("account");
    vec.push_back("isbn");
    vector<StudentBook> res;
    if (db.select("student-book", sb, vec, res) != -1)
        return true;
    else
        return false;
}

bool Utils::CheckBookClassificationExist(BookClassification bc){
    vector<string> vec;
    vec.push_back("not-all");
    vec.push_back("classification_id");
    vec.push_back("isbn");
    vector<BookClassification> res;
    if (db.select("book-classification", bc, vec, res) != -1)
        return true;
    else
        return false;
}

bool Utils::InsertUser(User user){
    if (!CheckUserExist(user)){
        vector<User> vec;
        vec.push_back(user);
        if (db.insert("user", vec) != -1)
            return true;
        else
            return false;
    }else{
        return false;
    }
}

bool Utils::InsertBook(Book book)  //参数为图书对象，功能为将图书插入数据文件，返回操作是否成功的结果
{
    if (!CheckBookExist(book)){
        vector<Book> entity;
        entity.push_back(book);
        if (db.insert("book", entity) != -1){
            return true;
        }else {
            return false;
        }
    }else {
        return false;
    }
}

bool Utils::InsertIsbnBookId(IsbnBookId ibi){
    if (!CheckIsbnBookIdExist(ibi)){
        vector<IsbnBookId> vec;
        vec.push_back(ibi);
        if (db.insert("isbn-book_id", vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

bool Utils::InsertStudentBook(StudentBook sb){
    if (!CheckStudentBookExist(sb)){
        vector<StudentBook> vec;
        vec.push_back(sb);
        if (db.insert("student-book", vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

bool Utils::InsertBookClassification(BookClassification bc){
    if (!CheckBookClassificationExist(bc)){
        vector<BookClassification> vec;
        vec.push_back(bc);
        if (db.insert("book-classification", vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

bool Utils::DeleteUser(User user){
    if (CheckUserExist(user)){
        vector<string> vec;
        vec.push_back("account");
        if (db.Delete("user", user, vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

bool Utils::DeleteBook(Book book){
    if (CheckBookExist(book)){
        vector<string> vec;
        vec.push_back("isbn");
        if (db.Delete("book", book, vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

bool Utils::DeleteIsbnBookId(IsbnBookId ibi){
    if (CheckIsbnBookIdExist(ibi)){
        vector<string> vec;
        vec.push_back("isbn");
        vec.push_back("book_id");
        if (db.Delete("isbn-book_id", ibi, vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

bool Utils::DeleteStudentBook(StudentBook sb){
    if (CheckStudentBookExist(sb)){
        vector<string> vec;
        vec.push_back("account");
        vec.push_back("isbn");
        if (db.Delete("student-book", sb, vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

bool Utils::DeleteBookClassification(BookClassification bc){
    if (CheckBookClassificationExist(bc)){
        vector<string> vec;
        vec.push_back("classification_id");
        vec.push_back("isbn");
        if (db.Delete("book-classification", bc, vec) != -1)
            return true;
        else
            return false;
    }else {
        return false;
    }
}

User Utils::GetUser(const char* account) //参数为学生账号，返回包含该学生信息的学生对象
{
    User user = User();
    user.setAccount(account);
    if (CheckUserExist(user))
    {
        vector<string> value("not-all", "account");
        vector<User> result;
        int pos = db.select("user", user, value, result);
        return result.at(0);
    }
    else{
        User user2 = User();
        return user2;
    }
}

Book Utils::GetBook(const char* isbn) // 参数为图书isbn，返回包含该图书信息的图书对象
{
    Book book = Book();
    book.setIsbn(isbn);
    if (CheckBookExist(book))
    {
        vector<string> value("not-all", "isbn");
        vector<Book> result;
        int pos = db.select("book", book, value, result);
        return result.at(0);
    }
    else{
        Book book = Book();
        return book;
    }
}

IsbnBookId Utils::GetIsbnBookId(const char* isbn, int book_id){
    IsbnBookId ibi = IsbnBookId();
    ibi.setIsbn(isbn);
    ibi.setBookId(book_id);
    if (CheckIsbnBookIdExist(ibi))
    {
        vector<string> value;
        value.push_back("not-all");
        value.push_back("isbn");
        value.push_back("book_id");
        vector<IsbnBookId> result;
        int pos = db.select("isbn-book_id", ibi, value, result);
        return result.at(0);
    }
    else{
        IsbnBookId ibi = IsbnBookId();
        return ibi;
    }
}

StudentBook Utils::GetStudentBook(const char* account, const char* isbn){
    StudentBook sb = StudentBook();
    sb.setIsbn(isbn);
    sb.setAccount(account);
    if (CheckStudentBookExist(sb))
    {
        vector<string> value;
        value.push_back("not-all");
        value.push_back("isbn");
        value.push_back("account");
        vector<StudentBook> result;
        int pos = db.select("student-book", sb, value, result);
        return result.at(0);
    }
    else{
        StudentBook sb = StudentBook();
        return sb;
    }
}

BookClassification Utils::GetBookClassification(const char* isbn, int classification_id){
    BookClassification bc = BookClassification();
    bc.setIsbn(isbn);
    bc.setClassification(classification_id);
    if (CheckBookClassificationExist(bc))
    {
        vector<string> value;
        value.push_back("not-all");
        value.push_back("isbn");
        value.push_back("classification_id");
        vector<BookClassification> result;
        int pos = db.select("book-classification", bc, value, result);
        return result.at(0);
    }
    else{
        BookClassification bc = BookClassification();
        return bc;
    }
}

bool Utils::UpdateUser(User before, User after){

}

bool Utils::UpdateBook(Book before, Book after){

}

bool Utils::UpdateIsbnBookId(IsbnBookId before, IsbnBookId after){

}

bool Utils::UpdateStudentBook(StudentBook before, StudentBook after){

}

bool Utils::UpdateBookClassification(BookClassification before, BookClassification after){

}

int Utils::Register(User user) //参数：学生对象，功能：注册新学生。返回值：0:账号已存在，1:注册成功, -1注册失败
{
    if (CheckUserExist(user))
        return 0;
    else{
        if (InsertUser(user))
            return true;
        else
            return false;
    }
}

int Utils::Login(const char* account, const char* password) //参数1:账号，参数2:密码，功能：用户登录。返回值：0:账户不存在；1:登陆成功；2:密码错误
{
    if (CheckUserExist(GetUser(account)))
    {
        User user = GetUser(account);
        if (strcmp(password, user.getPassword()))
            return 1;
        else
            return 2;
    }else{
        return 0;
    }
}

bool Utils::GetMarkRank(vector<Book>&result) //参数为存结果列表，返回图书列表对象，内容为按收藏数排序的前十个图书
{
    Rank rank;
    vector<string> value;
    value.insert(value.begin(), "all");
    vector<Rank> result_rank;
    int pos = db.select("mark_rank", rank, value, result_rank);
    if (pos != -1){
        Book book = Book();
        for (int i = 0; i < result_rank.size(); i ++ )
        {
            book = GetBook(result_rank.at(i).getIsbn());
            result.push_back(book);
        }
        return true;
    }
    else
        return false;
}

bool Utils::GetBorrowRank(vector<Book>&result) //参数为存结果列表，返回图书列表对象，内容为按历史借阅总数排序的前十个图书
{
    Rank rank;
    vector<string> value;
    value.insert(value.begin(), "all");
    vector<Rank> result_rank;
    int pos = db.select("borrow_rank", rank, value, result_rank);
    if (pos != -1){
        Book book = Book();
        for (int i = 0; i < result_rank.size(); i ++ )
        {
            book = GetBook(result_rank.at(i).getIsbn());
            result.push_back(book);
        }
        return true;
    }
    else
        return false;
}

bool Utils::GetRecommendList(User user, vector<Book>&result) //参数1为学生账号、参数2为存结果列表，返回值为该学生的推荐书目列表
{
    if (CheckUserExist(user)){
        StudentBook sb = StudentBook();
        sb.setAccount(user.getAccount());
        sb.setRecommend(true);
        vector<string> value;
        value.push_back("not-all");
        value.push_back("account");
        value.push_back("recommend");
        vector<StudentBook> result_recommend;
        if (db.select("student-book", sb, value, result_recommend) != -1)
        {
            Book book = Book();
            for (int i = 0; i < result_recommend.size(); i ++ )
            {
                book = GetBook(result_recommend.at(i).getIsbn());
                result.push_back(book);
            }
            return true;
        }
    }else
        return false;
}

bool Utils::GetMarkList(User user, vector<Book>&result) //参数1为学生账号，参数2为存结果列表，返回该用户的收藏列表
{
    if (CheckUserExist(user)){
        StudentBook sb = StudentBook();
        sb.setAccount(user.getAccount());
        sb.setMark(true);
        vector<string> value;
        value.push_back("not-all");
        value.push_back("account");
        value.push_back("mark");
        vector<StudentBook> result_mark;
        if (db.select("student-book", sb, value, result_mark) != -1)
        {
            Book book = Book();
            for (int i = 0; i < result_mark.size(); i ++ )
            {
                book = GetBook(result_mark.at(i).getIsbn());
                result.push_back(book);
            }
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
}

bool Utils::GetBorrowingList(User user, vector<IsbnBookId>&result) //参数1为学生账号，参数2为存结果列表，返回该用户的正在借书列表
{
    if (CheckUserExist(user)){
        IsbnBookId ibi = IsbnBookId();
        ibi.setBorrowAccount(user.getAccount());
        ibi.setIsBorrowed(true);
        vector<string> value;
        value.push_back("not-all");
        value.push_back("borrow_account");
        value.push_back("isBorrowed");
        if (db.select("isbn-book_id", ibi, value, result) != -1)
            return true;
        else
            return false;
    }else{
        return false;
    }
}

bool Utils::GetAppointmentList(User user, vector<IsbnBookId>&result) //参数1为学生账号，参数2为存结果列表，返回该用户预约的图书列表
{
    if (CheckUserExist(user)){
        IsbnBookId ibi = IsbnBookId();
        ibi.setAppointAccount(user.getAccount());
        ibi.setIsAppointed(true);
        vector<string> value;
        value.push_back("not-all");
        value.push_back("appoint_account");
        value.push_back("isAppointed");
        if (db.select("isbn-book_id", ibi, value, result) != -1)
            return true;
        else
            return false;
    }else{
        return false;
    }
}

bool Utils::Borrow(User user, Book book, int book_id) //参数1:借书学生账号，参数2:所借图书唯一编号，参数3:借书id，返回操作是否成功
{
    if (CheckUserExist(user)){
        if (CheckBookExist(book)){
            IsbnBookId ibi = IsbnBookId();
            ibi.setIsbn(book.getIsbn());
            ibi.setBookId(book_id);
            if (CheckIsbnBookIdExist(ibi)) {
                ibi = GetIsbnBookId(book.getIsbn(), book_id);
                if (!ibi.getIsBorrowed()) {
                    IsbnBookId after = ibi;
                    after.setIsBorrowed(true);
                    after.setBorrowAccount(user.getAccount());
                    if (!ibi.getIsAppointed()) {
                        if (!UpdateIsbnBookId(ibi, after))
                            return false;
                    }else {
                        if (strcmp(user.getAccount(), ibi.getAppointAccount())){
                            after.setIsAppointed(false);
                            if (!UpdateIsbnBookId(ibi, after))
                                return false;
                        }else {
                            return false;
                        }
                    }
                    Book after_book = book;
                    after_book.setLeft(book.getLeft() - 1);
                    after_book.setNumBorrow(book.getNumBorrow() + 1);
                    if (!UpdateBook(book, after_book))
                        return false;
                    StudentBook before_sb = GetStudentBook(user.getAccount(), book.getIsbn());
                    if (CheckStudentBookExist(before_sb)) {
                        StudentBook after_sb = before_sb;
                        after_sb.setIsInBorrowedHistory(true);
                        if (!UpdateStudentBook(before_sb, after_sb))
                            return false;
                        return true;
                    } else {
                        StudentBook sb = StudentBook();
                        sb.setIsbn(book.getIsbn());
                        sb.setAccount(user.getAccount());
                        sb.setMark(false);
                        sb.setRecommend(true);
                        sb.setIsInBorrowedHistory(true);
                        if (!InsertStudentBook(sb))
                            return false;
                        return true;
                    }
                }else {
                    return false;
                }
            }else {
                return false;
            }
        }else {
            return false;
        }
    }else {
        return false;
    }
}

bool Utils::Return(User user, Book book, int book_id) //参数1:还书学生账号，参数2:所还图书唯一编号，参数3:还书id，返回操作是否成功
{
    if (CheckUserExist(user)){
        if (CheckBookExist(book)){
            IsbnBookId ibi = IsbnBookId();
            ibi.setIsbn(book.getIsbn());
            ibi.setBookId(book_id);
            if (CheckIsbnBookIdExist(ibi)) {
                ibi = GetIsbnBookId(book.getIsbn(), book_id);
                if (ibi.getIsBorrowed()) {
                    IsbnBookId after = ibi;
                    after.setIsBorrowed(false);
                    if (!UpdateIsbnBookId(ibi, after))
                        return false;
                    Book after_book = book;
                    after_book.setLeft(book.getLeft() + 1);
                    if (!UpdateBook(book, after_book))
                        return false;
                }else {
                    return false;
                }
            }else {
                return false;
            }
        }else {
            return false;
        }
    }else {
        return false;
    }
}

bool Utils::Appoint(User user, Book book, int book_id) //参数1:续借学生账号，参数2:所借图书唯一编号，参数3:续借id，返回操作是否成功
{
    if (CheckUserExist(user)){
        if (CheckBookExist(book)){
            IsbnBookId ibi = IsbnBookId();
            ibi.setIsbn(book.getIsbn());
            ibi.setBookId(book_id);
            if (CheckIsbnBookIdExist(ibi)) {
                ibi = GetIsbnBookId(book.getIsbn(), book_id);
                if (ibi.getIsBorrowed()) {
                    IsbnBookId after = ibi;
                    after.setIsAppointed(true);
                    after.setAppointAccount(user.getAccount());
                    if (!ibi.getIsAppointed()) {
                        if (UpdateIsbnBookId(ibi, after))
                            return true;
                        else
                            return false;
                    }else {
                        return false;
                    }
                }else {
                    return false;
                }
            }else {
                return false;
            }
        }else {
            return false;
        }
    }else {
        return false;
    }
}

bool Utils::SetMark(User user, Book book, bool isMark) //参数1:收藏者的账号，参数2:所收藏图书isbn，参数3:加入收藏true取消收藏false， 返回操作是否成功
{
    if (CheckUserExist(user)){
        if (CheckBookExist(book)){
            StudentBook sb = StudentBook();
            sb.setIsbn(book.getIsbn());
            sb.setAccount(user.getAccount());
            if (CheckStudentBookExist(sb)){
                StudentBook before_sb = GetStudentBook(user.getAccount(), book.getIsbn());
                StudentBook after_sb = before_sb;
                after_sb.setMark(isMark);
                if (UpdateStudentBook(before_sb, after_sb)){
                    return true;
                }else {
                    return false;
                }
            }else {
                return false;
            }
        }else {
            return false;
        }
    }else {
        return false;
    }
}

bool Utils::GetBooksOfClassification(int classification_id, vector<Book>&result) //参数1为分区ID,参数2为存结果列表，返回操作是否成功
{
    BookClassification bc = BookClassification();
    bc.setClassification(classification_id);
    vector<string> value;
    value.push_back("not-all");
    value.push_back("classification");
    vector<BookClassification> res;
    if (db.select("book-classification", bc, value, res) != -1) {
        Book book;
        for (int i = 0; i < res.size(); i ++ )
        {
            book = GetBook(res.at(i).getIsbn());
            result.push_back(book);
        }
        return true;
    }else {
        return false;
    }
}

bool Utils::GetClassificationsOfBook(Book book, vector<int>&result) //参数为1为图书isbn，参数2为所属分区id存储列表，返回操作是否成功的结果
{
    BookClassification bc = BookClassification();
    bc.setIsbn(book.getIsbn());
    vector<string> value;
    value.push_back("not-all");
    value.push_back("isbn");
    vector<BookClassification> res;
    if (db.select("book-classification", bc, value, res) != -1) {
        for (int i = 0; i < res.size(); i ++ )
        {
            result.push_back(res.at(i).getClassification());
        }
        return true;
    }else {
        return false;
    }
}

bool Utils::CheckAdmin(User user){

} //参数为User对象，返回该用户是否是管理员，是true，不是false


bool Utils::UpdateMarkRank(){

} //更新收藏榜单，返回操作是否成功的结果。该操作需要管理员权限。


bool Utils::UpdateBorrowRank(){

} //更新历史借阅榜单，返回操作是否成功的结果。该操作需要管理员权限。


bool Utils::UpdateRecommandList(User user){

} //参数为User对象，操作为更新User对象的推荐列表，返回操作是否成功的结果

