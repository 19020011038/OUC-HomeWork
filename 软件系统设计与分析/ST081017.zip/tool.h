#ifndef TOOL_H
#define TOOL_H
#include <iostream>
#include"all_file_classes.h"
#include<vector>

using namespace std;

class Utils{
public:

    /*使用举例：
     * #include"tool.h"
     * Utils mUtils = Utils();
     * if(mUtils.UpdateMarkRank())
     *     printf("success");
     *
     *
     * 说明：默认参数均合法
     * 比如：GetUser函数默认参数中的user是存在的，因此若要使用该函数，请先调用CheckUserExist()进行检查
     *
     *
    */


    //*******************************
    // 以下均是对文件的单个唯一条目进行的操作
    static bool CheckUserExist(User user); //参数：学生对象，返回是否存在该条目


    static bool CheckBookExist(Book book); //参数：图书对象，返回是否存在该条目


    static bool CheckIsbnBookIdExist(IsbnBookId ibi); //参数：IsbnBookId对象，返回是否存在该条目


    static bool CheckStudentBookExist(StudentBook sb); //参数：StudentBook对象，返回是否存在该条目


    static bool CheckBookClassificationExist(BookClassification bc); //参数：BookClassification对象，返回是否存在该条目


    static bool InsertUser(User user); //参数：User对象，进行插入操作，返回是操作是否成功


    static bool InsertBook(Book book); //参数：Book对象，进行插入操作，返回是操作是否成功


    static bool InsertIsbnBookId(IsbnBookId ibi); //参数：IsbnBookId对象，进行插入操作，返回是操作是否成功


    static bool InsertStudentBook(StudentBook sb); //参数：StudentBook对象，进行插入操作，返回是操作是否成功


    static bool InsertBookClassification(BookClassification bc); //参数：BookClassification对象，进行插入操作，返回是操作是否成功


    static bool DeleteUser(User user); //参数：User对象，进行删除操作，返回操作是否成功的结果


    static bool DeleteBook(Book book); //参数：Book对象，进行删除操作，返回操作是否成功的结果


    static bool DeleteIsbnBookId(IsbnBookId ibi); //参数：IsbnBookId对象，进行删除操作，返回操作是否成功的结果


    static bool DeleteStudentBook(StudentBook sb); //参数：StudentBook对象，进行删除操作，返回操作是否成功的结果


    static bool DeleteBookClassification(BookClassification bc); //参数：BookClassification对象，进行删除操作，返回操作是否成功的结果


    static User GetUser(const char* account); //参数为用户账号，返回该账号对应的学生对象，账号不存在则返回一个默认构建的User对象


    static Book GetBook(const char* isbn); //参数为图书isbn，返回该账号对应的图书对象，isbn不存在则返回一个默认构建的Book对象


    static IsbnBookId GetIsbnBookId(const char* isbn, int book_id); //参数为图书isbn，返回该账号对应的图书对象，isbn不存在则返回一个默认构建的User


    static StudentBook GetStudentBook(const char* account, const char* isbn);
    //参数1为学生账号，参数2为图书isbn，返回唯一的StudentBook对象，检索对象不存在则返回一个默认构建的StudentBook对象


    static BookClassification GetBookClassification(const char* isbn, int classification_id);
    //参数1为图书isbn，参数2为分区id，返回唯一的BookClassification对象，检索对象不存在则返回一个默认构建的BookC对象


    static bool UpdateUser(User before, User after); //参数1为需要修改的User对象，参数2为修改后的User对象，返回修改操作是否成功的结果


    static bool UpdateBook(Book before, Book after); //参数1为需要修改的Book对象，参数2为修改后的Book对象，返回修改操作是否成功的结果


    static bool UpdateIsbnBookId(IsbnBookId before, IsbnBookId after); //参数1为需要修改的IsbnBookId对象，参数2为修改后的IsbnBookId对象，返回修改操作是否成功的结果



    static bool UpdateStudentBook(StudentBook before, StudentBook after);
    //参数1为需要修改的StudentBook对象，参数2为修改后的StudentBook对象，返回修改操作是否成功的结果


    static bool UpdateBookClassification(BookClassification before, BookClassification after);
    //参数1为需要修改的BookClassification对象，参数2为修改后的BookClassification对象，返回修改操作是否成功的结果
    //*******************************






    static int Register(User user); //参数：学生对象，功能：注册新学生。返回值：0:账号已存在，1:注册成功, -1注册失败


    static int Login(const char* account, const char* password); //参数1:账号，参数2:密码，功能：用户登录。返回值：0:账户不存在；1:登陆成功；2:密码错误


    static bool GetMarkRank(vector<Book>&result); //参数为存结果列表，返回图书列表对象，内容为按收藏数排序的前十个图书


    static bool GetBorrowRank(vector<Book>&result); //参数为存结果列表，返回图书列表对象，内容为按历史借阅总数排序的前十个图书


    static bool UpdateMarkRank(); //更新收藏排行榜，返回操作是否成功的结果


    static bool UpdateBorrowRank(); //更新历史借阅榜排行榜，返回操作是否成功的结果


    static bool GetBooksByBookName(const char* name, vector<Book>&result); //参数1为图书名，参数2为存结果列表，操作为根据书名检索图书，返回操作是否成功的结果


    static bool GetBooksByAuthor(const char* publisher, vector<Book>&result); //参数1为作者名，参数2为存结果列表，操作为根据作者名检索图书，返回操作是否成功的结果


    static Book GetBookByIsbn(const char* isbn); //参数1为isbn，返回isbn对应图书对象


    static bool GetBooksByClassificationId(int classification_id, vector<Book>&result); //参数1为分区id，参数2为存结果列表，操作为根据分区id检索图书，返回操作是否成功的结果


    static bool GetRecommendList(User user, vector<Book>&result); //参数1为User对象,参数2为存结果列表，返回值为该用户的推荐书目列表


    static bool UpdateRecommandList(User user); //参数为用户对象，操作为更新对该用户的推荐图书


    static bool GetMarkList(User user, vector<Book>&result); //参数1为User对象，参数2为存结果列表，返回该用户的收藏列表


    static bool GetBorrowingList(User user, vector<IsbnBookId>&result); //参数1为User对象，参数2为存结果列表，返回该用户的正在借书列表


    static bool GetAppointmentList(User user, vector<StudentBook>&result); //参数1为User对象，参数2为存结果列表，返回该用户预约的图书列表


    static bool Borrow(User user, Book book, int book_id); //参数1:借书者用户，参数2:所借图书唯一编号，参数3:借书id，返回操作是否成功


    static bool Return(User user, Book book, int book_id); //参数1:还书者用户，参数2:所还图书唯一编号，参数3:还书id，返回操作是否成功


    static bool Appoint(User user, Book book); //参数1:预约者用户，参数2:所预约图书isbn,返回操作是否成功


    static bool PreBorrow(User user, Book book); //参数1:取消预约者用户，参数2:所取消预约图书isbn,返回操作是否成功


    static bool GetBookIdsOfBook(Book book, vector<IsbnBookId>&result); //参数1为Book对象， 参数2为存结果列表，即该isbn所对应isbn-book_id文件中所有条目，返回操作是否成功的结果


    static bool SetMark(User user, Book book, int isMark); //参数1:收藏者用户，参数2:所收藏图书isbn，参数3:加入收藏1取消收藏0， 返回操作是否成功


    static bool GetBooksOfClassification(int classification_id, vector<Book>&result); //参数1为分区ID,参数2为存结果列表，返回操作是否成功


    static bool CheckAdmin(User user); //参数为User对象，返回该用户是否是管理员，是true，不是false


    static bool CheckIsFrooze(User user); //参数为用户对象，返回该用户是否被冻结的结果


    static bool SetUserFrooze(User user, int frooze); //参数1为用户对象，参数2为设置用户的冻结状态，1冻结2不冻结，返回操作是否成功的结果


    static int TransformClassification(const char* classification); //参数为分区的名称，返回分区编号


};

#endif // TOOL_H
