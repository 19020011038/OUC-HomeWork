#ifndef ALL_FILE_CLASSES_H
#define ALL_FILE_CLASSES_H

#include<typeinfo.h>
#include<typeinfo>
#include"student-book.h"
#include"user.h"
#include"book-classification.h"
#include"isbn-book_id.h"
#include"book.h"


#endif // ALL_FILE_CLASSES_H
