﻿#include "book_addonly.h"
#include "ui_book_addonly.h"
#include "book.h"
#include "tool.h"
#include <QTextCodec>
#include <config.h>
#include "book-classification.h"
#include <QMessageBox>
#include <iostream>
#include <QDebug>
#include <map>
using namespace  std;

Book_addOnly::Book_addOnly(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Book_addOnly)
{
    ui->setupUi(this);
}

Book_addOnly::~Book_addOnly()
{
    delete ui;
}

void Book_addOnly::on_pushButton_return_clicked()
{
    emit send_returnSignal();
    this->close();
}

void Book_addOnly::on_submit_clicked()
{
    Utils mutils = Utils();

    Book book;

    /*
    QString  str;
    char*  ch;
    QByteArray ba = str.toLocal8Bit(); // must
    ch=ba.data();*/

    int flag=0;

    QString str = ui->ISBN->text();

    QByteArray ba = str.toLocal8Bit();
    char *isbn = ba.data();
    if(str.length()<=0||str.length()>=ISBN_SIZE)flag=1;
    book.setIsbn(isbn);

    str = ui->name->text();
    ba = str.toLocal8Bit();
    char *name = ba.data();
    if(str.length()<=0||str.length()>=BOOK_NAME_SIZE)flag=1;

    book.setName(name);

    str = ui->author->text();
    //qDebug()<<str<<endl;
    ba = str.toLocal8Bit();
    char *author = ba.data();
    if(str.length()<=0||str.length()>=AUTHOR_SIZE)flag=1;
    book.setAuthor(author);

    str = ui->image->text();
    ba = str.toLocal8Bit();
    char *image = ba.data();
    if(str.length()<=0||str.length()>=IMAGE_SIZE)flag=1;
    book.setImage(image);

    str = ui->publish->text();
    ba = str.toLocal8Bit();
    char *publish = ba.data();
    if(str.length()<=0||str.length()>=PUBLISHER_SIZE)flag=1;
    book.setPublisher(publish);

    str = ui->publish_date_label->text();

    ba = str.toLocal8Bit();
    char *publish_date = ba.data();
    if(str.length()<=0||str.length()>=PUBLISH_DATE_SIZE)flag=1;
    book.setPublishDate(publish_date);


    str = ui->price->text();
    float price = str.toFloat();
    if(price<=0)flag=1;
    book.setPrice(price);


    str = ui->num->text();
    int num = str.toInt();
    if(num<=0)flag=1;
    book.setIdTotal(num-1);
    book.setLeft(num);
    book.setStorage(num);
    book.setNumBorrow(0);
    book.setNumMark(0);


    int cla[30]={0};
    cla[0]=ui->cla_0->isChecked();
    cla[1]=ui->cla_1->isChecked();
    cla[2]=ui->cla_2->isChecked();
    cla[3]=ui->cla_3->isChecked();
    cla[4]=ui->cla_4->isChecked();
    cla[5]=ui->cla_5->isChecked();
    cla[6]=ui->cla_6->isChecked();
    cla[7]=ui->cla_7->isChecked();
    cla[8]=ui->cla_8->isChecked();
    cla[9]=ui->cla_9->isChecked();
    cla[10]=ui->cla_10->isChecked();
    cla[11]=ui->cla_11->isChecked();
    cla[12]=ui->cla_12->isChecked();
    cla[13]=ui->cla_13->isChecked();
    cla[14]=ui->cla_14->isChecked();
    //cla[15]=ui->cla_15->isChecked();
    cla[15]=ui->cla_16->isChecked();
    cla[16]=ui->cla_17->isChecked();
    cla[17]=ui->cla_18->isChecked();
    cla[18]=ui->cla_19->isChecked();
    cla[19]=ui->cla_20->isChecked();
    cla[20]=ui->cla_21->isChecked();
    cla[21]=ui->cla_22->isChecked();


    QString clas;


    map<int,QString>mp;
    mp.insert({0,"哲学"});
    mp.insert({1,"人文社科综合"});
    mp.insert({2,"管理学"});
    mp.insert({3,"政治"});
    mp.insert({4,"法律"});
    mp.insert({5,"经济"});
    mp.insert({6,"文化/教育"});
    mp.insert({7,"语言/文学"});
    mp.insert({8,"艺术"});
    mp.insert({9,"历史"});
    mp.insert({10,"数学"});
    mp.insert({11,"物理"});
    mp.insert({12,"化学/材料"});
    mp.insert({13,"理工综合"});
    mp.insert({14,"地球科学"});
    mp.insert({15,"生物"});
    mp.insert({16,"医学/药学"});
    mp.insert({17,"农业/水产",});
    mp.insert({18,"工业技术"});
    mp.insert({19,"计算机/网络"});
    mp.insert({20,"环境"});
    mp.insert({21,"其他"});

    for(int i=0;i<=21;i++)
    {
        if(cla[i]==1)
        {
            clas+=mp[i];
            clas+=" ";
            BookClassification bc = BookClassification();

            bc.setIsbn(isbn);
            bc.setClassification(i);

            if(mutils.CheckBookClassificationExist(bc)==0&&flag==0)
            {
                mutils.InsertBookClassification(bc);
            }
        }
    }

    ba = clas.toLocal8Bit();
    char *Classification = ba.data();
    if(clas.length()<=0||clas.length()>=CLASSIFICATION_SIZE)flag=1;

    book.setClassification(Classification);

    str = ui->description->toPlainText();
    ba = str.toLocal8Bit();
    if(str.length()==0||str.length()>=DESCRIPTION_SIZE)flag=1;

    char *description =ba.data();
    book.setDescription(description);





    if(mutils.CheckBookExist(book)==0&&flag==0)
    {
        if(mutils.AddBook(book)==false)
        {
            flag=1;
        }
    }
    else flag=1;

    if(flag == 1)
    {
        QMessageBox msgBox;
        msgBox.setText("输入出现错误");
        msgBox.exec();
    }
    else
    {
        QMessageBox msgBox;
        msgBox.setText("提交成功");
        msgBox.exec();
        on_pushButton_return_clicked();

    }

}
