#ifndef MODIFY_BOOK_H
#define MODIFY_BOOK_H

#include <QMainWindow>
#include <iostream>

using namespace std;


namespace Ui {
class modify_book;
}

class modify_book : public QMainWindow
{
    Q_OBJECT

public:
    explicit modify_book(QWidget *parent = 0);
    ~modify_book();
    void get_book_info();//将原来的图书信息显示到对应位置上去

private slots:
    void on_pushButton_return_clicked();
    void on_submit_clicked();
signals:
    void send_returnSignal();

private:
    Ui::modify_book *ui;
    char *book_ISBN;
};

#endif // MODIFY_BOOK_H
