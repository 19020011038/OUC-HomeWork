﻿#include "usertemplate.h"
#include "ui_usertemplate.h"
#include"person.h"

usertemplate::usertemplate(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::usertemplate)
{
    ui->setupUi(this);

    fmain = new Person;

    connect(this,SIGNAL(sendsignal(char*)),fmain,SLOT(get_student_info(char*)));

    connect(fmain,SIGNAL(sendSignal()),this,SLOT(reshow()));
}

usertemplate::~usertemplate()
{
    delete ui;
}

void usertemplate::on_pushButton_4_clicked()
{
    cout<<this->getID()<<endl;
    emit sendsignal(this->getID());

    fmain->show();
    this->close();
}

void usertemplate::reshow()
{
    this->show();
}

void usertemplate::get_student_info(char *id)
{
    this->setID(id);
    cout<<"?"<<this->ID<<endl;
}
