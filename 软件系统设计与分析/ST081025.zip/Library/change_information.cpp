#include "change_information.h"
#include "ui_change_information.h"
#include "tool.h"
#include "user.h"
#include <QByteArray>
#include <QMessageBox>

change_information::change_information(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::change_information)
{
    ui->setupUi(this);
    ui->new_password->setEchoMode(QLineEdit::Password); 
    ui->confirm_password->setEchoMode(QLineEdit::Password);
    
    ui->old_password->setEchoMode(QLineEdit::Normal);
}

change_information::~change_information()
{
    delete ui;
}

void change_information::setID(char *id)
{
    strcpy(ID,id);
}

void change_information::on_pushButton_change_password_clicked()
{
    QString real_password;
    
    Utils mutils = Utils();
    User user=mutils.GetUser(ID);
    User old_user = mutils.GetUser(ID);

    real_password=QString(QLatin1String(user.getPassword()));
    
    QString oldpassword;
    oldpassword=ui->old_password->text();
    
    QString newpassword;
    newpassword=ui->new_password->text();

    QString confirmpassword;
    confirmpassword=ui->confirm_password->text();

    if(real_password!=oldpassword||newpassword!=confirmpassword)
    {
        QMessageBox msgBox;
        msgBox.setText("输入出现错误");
        msgBox.exec();
    }
    else
    {
        char*  ch;
        QByteArray ba = newpassword.toLatin1(); // must
        ch=ba.data();
        user.setPassword(ch);

        mutils.UpdateUser(old_user,user);

        QMessageBox msgBox;
        msgBox.setText("修改密码成功");
        msgBox.exec();

        on_pushButton_return_clicked();
        //实现修改密码的功能
    }
}

void change_information::on_pushButton_return_clicked()
{
    emit return_setting();
    this->close();
}
