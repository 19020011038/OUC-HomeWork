﻿#include "modify_student.h"
#include "ui_modify_student.h"
#include "user.h"
#include "tool.h"
#include <QMessageBox>

modify_student::modify_student(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::modify_student)
{
    ui->setupUi(this);
}

modify_student::~modify_student()
{
    delete ui;
}


void modify_student::on_pushButton_return_clicked()
{
    emit send_returnSignal();
    this->close();
}

void modify_student::on_submit_clicked()
{
    User user;

    Utils mutils = Utils();


    int flag=0;

    /*
    QString str = ui->ISBN->text();

    char isbn[ISBN_SIZE];
    QByteArray ba = str.toLocal8Bit();
    isbn = ba.data();
    if(str.length()<=0||str.length()>=ISBN_SIZE)flag=1;

    book.setIsbn(isbn);*/

    QString str = ui->account->text();
    QByteArray ba = str.toLocal8Bit();
    char *account = ba.data();
    if(str.length()<=0 || str.length()>=ACCOUNT_SIZE)flag=1;

    user.setAccount(account);


    str = ui->password->text();
    ba = str.toLocal8Bit();
    char *password = ba.data();
    if(str.length()<=0 || str.length()>=PASSWORD_SIZE)flag=1;

    user.setPassword(password);

    str = ui->name->text();
    ba = str.toLocal8Bit();
    char *name = ba.data();
    if(str.length()<=0 || str.length()>=USER_NAME_SIZE)flag=1;

    user.setName(name);

    str = ui->major->text();
    ba=str.toLocal8Bit();
    char *major = ba.data();
    if(str.length()<=0||str.length()>=MAJOR_SIZE)flag=1;

    user.setMajor(major);

    int sex;
    if(ui->sex_male->isChecked())sex=1;
    else if(ui->sex_female->isChecked())sex=0;
    user.setSex(sex);

    User user_old = mutils.GetUser(student_id);

    user.setIsAdmin(0);
    user.setNumAppointed(user_old.getNumAppointed());
    user.setNumBorrowed(user_old.getNumBorrowed());

    user.setFrooze(user_old.getFrooze());

    if(flag=0)
    {
        mutils.UpdateUser(user_old,user);
        QMessageBox msgBox;
        msgBox.setText("操作成功");
        msgBox.exec();
    }
    else
    {
        QMessageBox msgBox;
        msgBox.setText("输入出现错误");
        msgBox.exec();
    }
}

void modify_student::get_student_info()
{
    Utils mutils = Utils();
    User user = User();

    user = mutils.GetUser(student_id);

    char *ch;
    ch = user.getAccount();

    QString account = QString::fromLocal8Bit(ch);
    ui->account->setText(account);

    ch =user.getPassword();
    QString password = QString::fromLocal8Bit(ch);
    ui->password->setText(password);

    ch=user.getName();
    QString name = QString::fromLocal8Bit(ch);
    ui->name->setText(name);

    ch =user.getMajor();
    QString major =QString::fromLocal8Bit(ch);
    ui->major->setText(major);

    int sex=user.getSex();
    QString sex_t = QString("%1").arg(sex);

    if(sex==1)
    {
        ui->sex_male->setChecked(true);
    }
    else ui->sex_female->setChecked(true);

}
