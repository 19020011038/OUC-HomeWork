﻿#include "books_add.h"
#include "ui_books_add.h"
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include "read_excel.h"
#include "book.h"
#include "filedb.h"
#include <iostream>
#include "user.h"
#include <sstream>
#include "isbn-book_id.h"
#include "tool.h"
#include <QTextCodec>
#include<QRegExpValidator>
#include "config.h"
#include <QTextCodec>
#include <QString>

Books_add::Books_add(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Books_add)
{
    ui->setupUi(this);
    fmain = new Book_addOnly;

    connect(fmain,SIGNAL(send_returnSignal()),this,SLOT(reshow()));

}

Books_add::~Books_add()
{
    delete ui;
}


void Books_add::on_Add_return_clicked()
{
    emit send_AddSignal();
    this->close();
}

void Books_add::reshow()
{
    this->show();
}


void Books_add::on_AddMany_clicked()
{
    QMessageBox::information(NULL, QString::fromLocal8Bit(""), "请选择Excel文件,文件中列序按照ISBN、书名、作者、封面路径、出版社、出版时间、单价、总量、简介、分类排好", QMessageBox::Ok);
    QString excelPath = QFileDialog::getOpenFileName(this, "选择Exccel", "", tr("Excel (*.xls *.xlsx)"));

    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF8"));

    if (excelPath.isEmpty()) {
        return;
    }
    ReadExcel read;
    excelPath.replace(QString("/"), QString("\\"));
    read.openExcel(excelPath);

    int col, row;
    read.getInfo(row, col);
    Book book;

    int sumBooks = 0;


    for (int i = 1; i <= row; i++) {

            QString str;
            QByteArray ba2;
            //qDebug()<<read.getCellData(i,2)<<endl;

            //string ISBN = read.getCellData(i, 1).toStdString();
            ba2 = read.getCellData(i,1).toLocal8Bit();
            char *isbn = ba2.data();

            //if (!checkISBN(ISBN))continue;
            book.setIsbn(ba2.data());

            QByteArray ba;
            ba = read.getCellData(i,10).toLocal8Bit();
            char *cla = ba.data();
            book.setClassification(ba.data());

            Utils mutils = Utils();


            QByteArray ba3;
            ba3 = read.getCellData(i,2).toLocal8Bit();
            char *name = ba3.data();
            cout<<isbn<<endl;
            if(ba3.size() ==0 ||ba3.length()>=BOOK_NAME_SIZE)continue;
            book.setName(name);

            QByteArray ba4;
            ba4 = read.getCellData(i,3).toLocal8Bit();
            char *author = ba4.data();
            if(ba4.size() ==0 ||ba4.length()>=AUTHOR_SIZE)continue;
            book.setAuthor(author);

            QByteArray ba5;
            ba5 = read.getCellData(i,4).toLocal8Bit();
            char *image = ba5.data();
            if(ba5.size() ==0 ||ba5.length()>=IMAGE_SIZE)continue;
            book.setImage(image);

            QByteArray ba6;
            ba6 = read.getCellData(i,5).toLocal8Bit();
            char *publish = ba6.data();
            if(ba6.size() ==0 ||ba6.length()>=PUBLISHER_SIZE)continue;
            book.setPublisher(publish);

            QByteArray ba7;
            ba7 = read.getCellData(i,6).toLocal8Bit();
            char *publish_time = ba7.data();
            if(ba7.size() ==0 ||ba7.length()>=PUBLISH_DATE_SIZE)continue;
            book.setPublishDate(publish_time);

            QByteArray ba8;
            ba8 = read.getCellData(i,9).toLocal8Bit();
            char *description = ba8.data();
            //cout<<description<<endl;
            if(ba8.size() ==0 ||ba8.length()>=DESCRIPTION_SIZE)continue;
            book.setDescription(description);



            /*
            string name = read.getCellData(i, 2).toStdString();
            string author = read.getCellData(i, 3).toStdString();
            string image = read.getCellData(i, 4).toStdString();
            string publish = read.getCellData(i, 5).toStdString();
            string publish_time = read.getCellData(i, 6).toStdString();
            string description = read.getCellData(i, 9).toStdString();


            //if (name.length() == 0 || name.length() >= BOOK_NAME_SIZE)continue;
            if (author.length() == 0 || author.length() >= AUTHOR_SIZE)continue;
            if (publish.length() == 0 || publish.length() >= PUBLISHER_SIZE)continue;
            if (image.length() == 0 || image.length() >= IMAGE_SIZE)continue;
            if (publish_time.length() == 0 || publish_time.length() >= PUBLISH_DATE_SIZE)continue;
            if (description.length() == 0 || description.length() >= DESCRIPTION_SIZE)continue;

            book.setName((char*)name.data());
            book.setAuthor((char*)author.data());
            book.setPublisher((char*)publish.data());
            book.setImage((char*)image.data());
            book.setPublishDate((char*)publish_time.data());
            book.setDescription((char*)description.data());
            */

            string nummm = read.getCellData(i, 8).toStdString();
            //if (!checkCount(nummm))continue;
            int numC = read.getCellData(i, 8).toInt();
            if(numC<=0)continue;
            string scoreee = read.getCellData(i, 7).toStdString();
            //if (!checkScore(scoreee))continue;
            float score = read.getCellData(i, 7).toFloat();
            if(score<=0)continue;
            book.setPrice(score);
            book.setIdTotal(numC-1);
            book.setStorage(numC);
            book.setLeft(numC);
            book.setNumMark(0);
            book.setNumBorrow(0);

            if(mutils.AddBook(book)==false)continue;


            Book new_book = mutils.GetBook(isbn);


           /* QString str2 =QString::fromLocal8Bit(new_book.getName());
            ui->test->setText(str2);
            cout<<new_book.getIsbn()<<endl;
            cout<<new_book.getName()<<endl;
            cout<<new_book.getClassifition()<<endl;*/

            QString cla_2=new_book.getClassifition();
           // cout<<cla_2<<endl;
            QStringList cla_tem = cla_2.split(" ");
           // vector<QString>cla_tem;
            /*stringstream input(cla_2);
            string tem;
            while(input>>tem)
            {
                cla_tem.push_back(tem);
                cout<<tem<<endl;
            }*/

            int c_flag=0;

            for(int i=0;i< cla_tem.size();i++)
            {
                int x_tem;
                //qDebug()<<cla_tem[i]<<endl;
                x_tem=mutils.TransformClassification(cla_tem[i]);
                //classification_id.push_back(x_tem);

                BookClassification bc = BookClassification();
                bc.setIsbn(isbn);
                //cout<<x_tem<<endl;
                if(x_tem==-1)continue;
                bc.setClassification(x_tem);

                if(mutils.CheckBookClassificationExist(bc)==0)
                    mutils.InsertBookClassification(bc);
                else continue;
            }

            sumBooks++;
    }
    QString success = QString::number(sumBooks);
    QMessageBox::information(NULL, QString::fromLocal8Bit(""), success + "本图书导入成功", QMessageBox::Ok);
}

bool Books_add::checkISBN(string ISBN) {

    if (ISBN.length() == 0 || ISBN.length() >= 14)return false;
    QRegExp rx("[1-9][0-9]+");
    QRegExpValidator v(rx, 0);
    int pos = 0;
    QString qs=QString::fromStdString(ISBN);

    int res = v.validate(qs, pos);
    if (!res) {
        return false;
    }
    //判断ISBN是否重复
    Book book;
    vector<string>VALUES;
    vector<Book>resBook;
    VALUES.push_back("one");
    VALUES.push_back("isbn");

    book.setIsbn((char*)ISBN.data());

    Utils mutils = Utils();

    if(mutils.CheckBookExist(book))
    {
        return true;
    }
    else return false;
}

void Books_add::on_AddOnly_clicked()
{
    fmain->show();
    this->close();
}
