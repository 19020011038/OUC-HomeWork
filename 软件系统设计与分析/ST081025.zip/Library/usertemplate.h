﻿#ifndef USERTEMPLATE_H
#define USERTEMPLATE_H

#include <QDialog>
#include <config.h>
#include<person.h>

namespace Ui {
class usertemplate;
}

class usertemplate : public QDialog
{
    Q_OBJECT

public:
    explicit usertemplate(QWidget *parent = nullptr);
    ~usertemplate();
    void setID(char *id)
    {
        cout << "get parameter" << id<<endl;
        for (int i = 0 ; i < ACCOUNT_SIZE; i ++)
            this->ID[i] = id[i];
        cout << "in set id "<< ID<<endl;
    }
    char *getID(){return ID;}

private slots:
    void on_pushButton_4_clicked();
    void reshow();
    void get_student_info(char *id);

signals:
    void sendsignal(char *id);

private:
    Ui::usertemplate *ui;
    char ID[ACCOUNT_SIZE];
    Person *fmain;
};

#endif // USERTEMPLATE_H
