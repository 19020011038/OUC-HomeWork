﻿#include "add_book.h"
#include "ui_add_book.h"
#include "book.h"
#include "tool.h"
#include <QMessageBox>

Add_Book::Add_Book(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Add_Book)
{
    ui->setupUi(this);
}

Add_Book::~Add_Book()
{
    delete ui;
}

void Add_Book::on_pushButton_return_clicked()
{
    emit send_returnSiganl();
    this->close();
}

void Add_Book::setIsbn(char *ISBN)
{
    id=ISBN;
}

void Add_Book::on_submit_clicked()
{
    Utils mutils = Utils();

    Book book;
    book = mutils.GetBookByIsbn(id);

    Book book_2 = mutils.GetBookByIsbn(id);
    int old_left =book_2.getLeft();
    int old_storage=book_2.getStorage();

    int num=ui->add_num->text().toInt();
    if(num<=0)
    {
        QMessageBox msgBox;
        msgBox.setText("输入错误");
        msgBox.exec();
    }
    else
    {
        book_2.setLeft(old_left+num);
        book_2.setStorage(old_storage+num);

        mutils.UpdateBook(book,book_2);

        QMessageBox msgBox;
        msgBox.setText("操作成功");
        msgBox.exec();
        on_pushButton_return_clicked();
    }


}


