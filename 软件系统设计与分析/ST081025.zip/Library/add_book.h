#ifndef ADD_BOOK_H
#define ADD_BOOK_H

#include <QMainWindow>

namespace Ui {
class Add_Book;
}

class Add_Book : public QMainWindow
{
    Q_OBJECT

public:
    explicit Add_Book(QWidget *parent = 0);
    ~Add_Book();

private slots:
    void on_pushButton_return_clicked();
    void on_submit_clicked();
    void setIsbn(char *ISBN);

signals:
    void send_returnSiganl();


private:
    Ui::Add_Book *ui;
    char *id;
};

#endif // ADD_BOOK_H
